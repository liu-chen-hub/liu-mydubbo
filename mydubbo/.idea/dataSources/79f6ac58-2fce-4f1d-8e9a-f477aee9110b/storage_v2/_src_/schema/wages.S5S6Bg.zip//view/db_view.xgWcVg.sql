create view db_view as
select `wages`.`studentinfo`.`id`        AS `id`,
       `wages`.`studentinfo`.`name`      AS `name`,
       `wages`.`studentinfo`.`CompanyId` AS `CompanyId`,
       `wages`.`studentinfo`.`PosteDate` AS `PosteDate`,
       `wages`.`studentinfo`.`wage`      AS `wage`
from `wages`.`studentinfo`
where (`wages`.`studentinfo`.`CompanyId` is not null);

